# RGBCraft Texture

Texture pack di default per **RGBcraft** contiene tutti i file necessari per apportare modifiche alla texture / modificare alcune textures oppure per creare una texture sulla base della default

Basata sulla Faithful 1.4.7 con aggiunte da parte di (in ordine casuale):
- Piccionenberg
- Roovy
- Alex3025
- lego11


