#!/bin/bash
bash genvariables.sh
echo 
bash gensign.sh
echo 
bash genblockregister.sh
echo 
bash genitem.sh
